import java.io.*;
import java.util.Scanner;


public class KrcText
{
    //酷狗krc歌词密文组成
    private static final char[] miarry = { '@', 'G', 'a', 'w', '^', '2', 't',
            'G', 'Q', '6', '1', '-', 'Î', 'Ò', 'n', 'i' };

    public static void main(String[] args) throws IOException
    {
        //new KrcText().getKrcText("D:\\墨智音乐 - KRC\\墨智音乐_2.0.1\\墨智音乐_2.0.1\\bin\\Debug\\netcoreapp3.1\\Resource\\Mrc\\贾卿卿、Vivian Wang - 献天缘.krc");

        Scanner input = new Scanner(System.in);

        System.out.println("输入krc文件所在的文件夹");
        String path = input.next();
        //String path = "D:\\墨智_毒蛇讯息（简单音乐播放器）1.0.1\\LRC_Text";

        File file = new File(path);		//获取其file对象
        File[] fs = file.listFiles();	//遍历path下的文件和目录，放在File数组中
        for(File f:fs)					//遍历File[]数组
            if(!f.isDirectory())        //若非目录(即文件)，则打印
                if(f.toString().indexOf("krc") > 0)
                    System.out.println(new KrcText().getKrcText(f.toString()));

    }


    /**
     *
     * @param filenm krc文件路径加文件名
     * @return krc文件处理后的文本
     * @throws IOException
     */
    public String getKrcText(String filenm) throws IOException
    {
        String fileenm_Lrc = filenm;

        File krcfile = new File(filenm);
        byte[] zip_byte = new byte[(int) krcfile.length()];
        FileInputStream fileinstrm = new FileInputStream(krcfile);
        byte[] top = new byte[4];
        fileinstrm.read(top);
        fileinstrm.read(zip_byte);
        int j = zip_byte.length;
        for (int k = 0; k < j; k++)
        {
            int l = k % 16;
            int tmp67_65 = k;
            byte[] tmp67_64 = zip_byte;
            tmp67_64[tmp67_65] = (byte) (tmp67_64[tmp67_65] ^ miarry[l]);
        }
        String krc_text = new String(ZLibUtils.decompress(zip_byte), "utf-8");


        //输入流
        File f = new File(fileenm_Lrc);
        FileOutputStream fop = new FileOutputStream(f);
        // 构建FileOutputStream对象,文件不存在会自动新建

        OutputStreamWriter writer = new OutputStreamWriter(fop, "UTF-8");
        // 构建OutputStreamWriter对象,参数可以指定编码,默认为操作系统默认编码,windows上是gbk

        /*writer.append("中文输入");
        // 写入到缓冲区
        writer.append("\r\n");
        // 换行
        writer.append("English");*/

        writer.append(krc_text);
        // 刷新缓存冲,写入到文件,如果下面已经没有写入的内容了,直接close也会写入

        writer.close();
        // 关闭写入流,同时会把缓冲区内容写入文件,所以上面的注释掉

        fop.close();
        // 关闭输出流,释放系统资源

        //输出流
        /*FileInputStream fip = new FileInputStream(f);
        // 构建FileInputStream对象

        InputStreamReader reader = new InputStreamReader(fip, "UTF-8");
        // 构建InputStreamReader对象,编码与写入相同

        StringBuffer sb = new StringBuffer();
        // 转成char加到StringBuffer对象中

        while (reader.ready()) { sb.append((char) reader.read());

        }

        //System.out.println(sb.toString());

        reader.close();
        // 关闭读取流

        fip.close();
        // 关闭输入流,释放系统资源*/


        return krc_text;
    }
}
