import java.io.File;
import java.util.Scanner;

public class A_ReName_LRC {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("输入krc文件所在的文件夹");
        String path = input.next();

        //String path = "D:\\墨智_毒蛇讯息（简单音乐播放器）1.0.1\\LRC_Text";

        File file = new File(path);        //获取其file对象
        File[] fs = file.listFiles();    //遍历path下的文件和目录，放在File数组中
        for (File f : fs)                    //遍历File[]数组
            if (!f.isDirectory())        //若非目录(即文件)，则打印
                if (f.toString().indexOf("krc") > 0) {
                    File files = new File(f.toString()); //指定文件名及路径

                    try {
                        String names = files.toString();
                        System.out.println(names);//后弦 - 下完这场雨-2eefff98a4f19d945bba7c78fb2079c0-26085731

                        String temp = names.substring(names.indexOf(" - ") + 3,names.length());
                        temp = temp.substring(0,temp.indexOf("-"));


                        names = names.substring(0,names.lastIndexOf(" - "));
                        names = names + " - " + temp + ".krc";

                        System.out.println(names);//后弦 - 下完这场雨.krc

                        files.renameTo(new File(names)); //改名
                    }catch (Exception es) {
                        System.err.println("\n"+files.toString());
                    }
                    System.out.println("\n\n\n");
                }
                
    }
}
