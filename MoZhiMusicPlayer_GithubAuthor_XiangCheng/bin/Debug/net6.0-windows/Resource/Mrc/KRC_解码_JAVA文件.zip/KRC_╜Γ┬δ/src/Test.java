import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);

        /*int[] nums = new int[]{8,4,2,1,23,344,12};

        for (int i = 0; i < nums.length; i++) {
            System.out.println(nums[i]);
        }

        int sum= 0;
        for (int i = 0; i < nums.length; i++) {
            sum += nums[i];
        }
        System.out.println("和：" + sum);

        System.out.println("请输入");
        int temp = inout.nextInt();
        boolean tex = false;

        for (int i = 0; i < nums.length; i++) {
            if (temp == nums[i]){
                System.out.println("包含");
                tex = true;
            }
        }
        if(!tex){
            System.out.println("不包含");
        }*/



        int nums[];
        nums = new int[3];
        nums[0] = 10;
        nums[1] = 20;
        nums[2] = 30;
        int [] nums1 = {10,20,30,40};//只能在同一行中完成
        int nums2[];
        nums2 = new int[]{10,20,30,40};
        int nums3[] = new int[]{10,20,30,40};
        for(int i = 0;i < nums1.length;i ++) {
            System.out.println(nums1[i]);
        }
        for(int i = 0;i < nums2.length; i ++) {
            System.out.println(nums2[i]);
        }
        for (int i = 0;i< nums3.length; i ++){
            System.out.println(nums3[i]);
        }
    }
}
